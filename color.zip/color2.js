function setbgcolor() {
    var color = prompt("enter color");
    document.body.style.backgroundColor = color;
    document.getElementById("color").innerHTML = color;
}